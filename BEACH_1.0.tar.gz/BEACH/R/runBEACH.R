runBEACH <-
function(){
  require(shiny)
  shiny::runApp(system.file('app', package='BEACH'))
}
