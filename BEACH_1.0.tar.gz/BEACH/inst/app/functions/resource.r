conditionalPanel(condition='true',
                 h5(a('COSMIC Database',href='http://cancer.sanger.ac.uk/cancergenome/projects/cosmic/',target='_blank')),
                 h5(a('Memorial Sloan Kettering cBioPortal Cancer Genomics Database',href='http://www.cbioportal.org/public-portal/',target='_blank')),
                 h5(a('Roche Genome Cancer Database',href='http://rcgdb.bioinf.uni-sb.de/MutomeWeb/',target='_blank'))
)
